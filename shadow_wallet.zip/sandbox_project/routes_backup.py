from flask import Blueprint, request, jsonify, abort, render_template
from functools import wraps
import secrets

from config import Config
from models import DatabaseManager

api_blueprint = Blueprint("api", __name__)


def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = request.headers.get("X-Admin-Token")

        if not token or not secrets.compare_digest(token, Config.ADMIN_TOKEN):
            return jsonify({
                "status": "failed",
                "reason": "Unauthorized"
            }), 401

        return f(*args, **kwargs)

    return decorated_function


@api_blueprint.before_request
def security_firewall():
    client_ip = request.remote_addr or "unknown"

    if DatabaseManager.is_ip_banned(client_ip):
        abort(404)

    request_path = request.path.lower()

    for path in Config.SUSPICIOUS_PATHS:
        if request_path.startswith(path):
            DatabaseManager.ban_ip(
                client_ip,
                f"Suspicious path: {request.path}"
            )
            abort(404)", methods=["GET"])) 
def admin_dashboard(): 
@api_blueprint.route("/admin/api/live-data", 
methods=["GET"]) @admin_required def 
get_live_dashboard_data():
    return render_template("admin.html")    try:
        with DatabaseManager.get_db_connection() as conn:
            rows = conn.execute(
                "SELECT * FROM transactions ORDER BY created_at DESC"
            ).fetchall()

            transactions = [dict(row) for row in rows]

        return jsonify({
            "status": "success",
            "transactions": transactions
        })

    except Exception as e:
        return jsonify({
            "status": "failed",
            "reason": str(e)
        }), 500


@api_blueprint.route("/api/test-transfer", methods=["POST"])
def test_transfer():
    try:
        data = request.get_json()

        required = [
            "app_id",
            "sender",
            "receiver_phone",
            "amount"
        ]

        if not data or not all(key in data for key in required):
            return jsonify({
                "status": "failed",
                "reason": "Missing fields"
            }), 400

        tx_id = DatabaseManager.create_transaction(data)

        return jsonify({
            "status": "success",
            "transaction_id": tx_id,
            "state": "PROCESSING_VERIFICATION"
        }), 201

    except Exception as e:
        return jsonify({
            "status": "failed",
            "reason": str(e)
        }), 500


@api_blueprint.route("/api/transaction/<int:tx_id>", methods=["GET"])
def get_transaction_status(tx_id):
    transaction = DatabaseManager.get_transaction(tx_id)

    if not transaction:
        return jsonify({
            "status": "failed",
            "reason": "Not found"
        }), 404

    return jsonify({
        "status": "success",
        "transaction": transaction
    })
